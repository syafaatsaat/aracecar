﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public enum GameStates 
    {
        IDLE,
        EDIT,
        PLAY,
        PAUSE
    };
    
    GameStates currState;

    List<GameObject> waypoints;

    [SerializeField]
    GameObject RaceCarPrefab;

    public GameObject RaceCar;

    // Start is called before the first frame update
    void Start()
    {
        currState = GameStates.IDLE;
        waypoints = new List<GameObject>();
    }

    // Update is called once per frame
    void Update()
    {
        if (currState == GameStates.PLAY)
        {
            // TODO: Run AI

        }
    }

    // Adds a waypoint to the list
    // The first added waypoint will be set as the starting point
    public void AddWaypoint(GameObject instance)
    {
        waypoints.Add(instance);
        if (waypoints.Count == 1)
        {
            instance.GetComponent<WaypointScript>().SetIsStartingPoint(true);
        }
    }

    // Deletes all waypoints in the list
    public void ClearWaypoints()
    {
        foreach (GameObject waypoint in waypoints)
        {
            Destroy(waypoint);
        }
        waypoints.Clear();
    }

    // Deletes a waypoint in the scene
    public void DeleteWaypoint(GameObject waypoint)
    {
        waypoints.Remove(waypoint);
        Destroy(waypoint);
    }

    // Returns the number of waypoints currently placed in scene
    public int GetWaypointCount()
    {
        return waypoints.Count;
    }

    // Sets all the other waypoint to not be starting point since 
    // caller GameObject has set itself as starting point
    public void ToggleWaypointStarting(GameObject caller)
    {
        for (int i = 0; i < waypoints.Count; ++i)
        {
            GameObject waypoint = waypoints[i];

            if (waypoint == caller)
            {
                continue;
            }

            WaypointScript wps = waypoint.GetComponent<WaypointScript>();
            wps.SetIsStartingPoint(false);
        }
    }

    // Loops through the waypoints to find the starting point
    int FindStartingPoint()
    {
        for (int i = 0; i < waypoints.Count; ++i)
        {
            GameObject waypoint = waypoints[i];

            WaypointScript wps = waypoint.GetComponent<WaypointScript>();
            if (wps.GetIsStartingPoint())
            {
                return i;
            }    
        }

        // Reach here means cannot find
        return -1;
    }

    // Returns the current game state
    public GameStates GetGameState()
    {
        return currState;
    }

    // Changes the game state to the passed in state
    public void ChangeGameState(GameStates state)
    {
        if (currState == GameStates.IDLE)
        {
            IdleState(state);
        }
        else if (currState == GameStates.EDIT)
        {
            EditState(state);
        }
        else if (currState == GameStates.PLAY)
        {
            PlayState(state);
        }
        else if (currState == GameStates.PAUSE)
        {
            PauseState(state);
        }
    }

    // Idle game state
    void IdleState(GameStates state)
    {
        if (state == GameStates.EDIT)
        {
            currState = state;
        }
        else if (state == GameStates.PLAY)
        {
            if (waypoints.Count < 3)
            {
                // Cannot start when have less than 3 waypoints
                return;
            }

            // If can find starting point, switch state
            int startingWaypointIndex = FindStartingPoint();
            if (startingWaypointIndex != -1)
            {
                // Instantiate racecar at starting point
                GameObject startingPoint = waypoints[startingWaypointIndex];
                Transform startTransform = startingPoint.transform;
                RaceCar = Instantiate(RaceCarPrefab, startTransform.position, startTransform.rotation);

                currState = state;
            }
            // Otherwise, don't change state
            else
            {
                //Debug.LogError("Starting point is not set. Please set one of the waypoint as the starting point.");
            }
        }
    }

    // Edit game state
    void EditState(GameStates state)
    {
        if (state == GameStates.IDLE)
        {
            currState = state;
        }
    }

    // Play game state
    void PlayState(GameStates state)
    {
        if (state == GameStates.IDLE)
        {
            // TODO: Stop AI or maybe no need

            // Reset position of car to starting waypoint
            // OR just delete the racecar because it only appears when
            // the user presses PLAY
            Destroy(RaceCar);

            currState = state;
        }
        else if (state == GameStates.PAUSE)
        {
            // TODO: Pause AI OR maybe no need coz in Update, AI only runs
            // in PLAY state


            currState = state;
        }
    }

    // Pause game state
    void PauseState(GameStates state)
    {
        if (state == GameStates.PLAY)
        {
            currState = state;
        }
    }
}
