﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaypointScript : MonoBehaviour
{
    [SerializeField]
    bool IsStartingPoint;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // If waypoint is starting point, set color to green
        if (IsStartingPoint)
        {
            MeshRenderer mr = GetComponentInChildren<MeshRenderer>();
            mr.material.SetColor("_Color", Color.green);
        }
    }

    // Returns whether this waypoint is the starting point or not
    public bool GetIsStartingPoint()
    {
        return IsStartingPoint;
    }

    // Sets this waypoint to be starting point or not
    // If it is not and will be set to starting point, it will call
    // the Game Manager to set all other waypoints to not be starting point
    public void SetIsStartingPoint(bool value)
    {
        if (value == true && IsStartingPoint == false)
        {
            GameObject gm = GameObject.Find("GameManagerEnt");
            gm.GetComponent<GameManager>().ToggleWaypointStarting(gameObject);
        }

        IsStartingPoint = value;
    }
}
