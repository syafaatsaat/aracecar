﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIButton : MonoBehaviour
{
    private GameObject gameManagerEnt;

    [SerializeField]
    public GameObject ARSessionOrigin;

    [SerializeField]
    GameObject DeleteButton;

    // Start is called before the first frame update
    void Start()
    {
        gameManagerEnt = GameObject.FindGameObjectWithTag("PathCreator");
    }

    // Update is called once per frame
    void Update()
    {
        Text childText = GetComponentInChildren<Text>();
        GameManager gameMan = gameManagerEnt.GetComponent<GameManager>();

        if (gameMan.GetGameState() == GameManager.GameStates.EDIT)
        {
            childText.text = "EDIT";
        }
        else if(gameMan.GetGameState() == GameManager.GameStates.ADD)
        {
            childText.text = "ADD";
        }
    }

    public void ChangeState(bool value)
    {
        if (value)
        {
            gameManagerEnt.GetComponent<GameManager>().ChangeGameState(GameManager.GameStates.EDIT);
        }
        else
        {
            gameManagerEnt.GetComponent<GameManager>().ChangeGameState(GameManager.GameStates.ADD);
            DeleteButton.SetActive(false);
        }
    }

    public void DeleteButtonClicked()
    {
        GameObject tobedeleted = ARSessionOrigin.GetComponent<PlaceObjectOnPlane>().m_LastClickedObject;

        if (tobedeleted != null)
        {
            gameManagerEnt.GetComponent<GameManager>().DeleteWaypoint(tobedeleted);
            DeleteButton.SetActive(false);
        }
    }
}
