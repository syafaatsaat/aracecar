﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

using PathCreation.Examples;

namespace PathCreation.AR 
{
    [RequireComponent(typeof(PathCreator))]
    public class ARPathGenerator : MonoBehaviour
    {
        public List<Transform> waypoints;
        BezierPath bezierPath;
        public Material roadMat;
        public Material underMat;

        // Start is called before the first frame update
        void Start()
        {
            if (waypoints.Count > 0)
            {
                // Create a new bezier path from the waypoints.
                bezierPath = new BezierPath(waypoints, true, PathSpace.xyz);
                GetComponent<PathCreator>().bezierPath = bezierPath;

                gameObject.AddComponent<RoadMeshCreator>();
                RoadMeshCreator rmc = gameObject.GetComponent<RoadMeshCreator>();
                rmc.roadMaterial = roadMat;
                rmc.undersideMaterial = underMat;
            }
        }

        // Update is called once per frame
        void Update()
        {
            
        }

        public void AddWaypoint(Transform waypoint)
        {
            waypoints.Add(waypoint);
        }

        public void DestroyPath()
        {
            // Destroy path
            // waypoints.Clear();
        }
    }
}